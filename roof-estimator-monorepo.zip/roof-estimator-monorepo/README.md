# Northline Roofing Config-Driven Estimator

Full-stack assignment implementation with:

- React + Vite frontend
- Express.js REST API
- MongoDB + Mongoose
- Dynamic estimator configuration from the database
- Server-side pricing calculation
- Basic-auth protected owner panel
- Lead storage and viewing
- Required DECISIONS.md and AI_LOG.md

## 1. Requirements

- Node.js 18+
- MongoDB Atlas or local MongoDB
- Git

## 2. Project structure

```text
roof-estimator-monorepo/
├── client/
├── server/
├── DECISIONS.md
├── AI_LOG.md
├── README.md
└── package.json
```

## 3. Install

From the root:

```bash
npm install
npm run install:all
```

Create `server/.env` from `server/.env.example`.

Example:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/roof_estimator
ADMIN_USERNAME=admin
ADMIN_PASSWORD=roofing2026!
CLIENT_ORIGIN=http://localhost:5173
```

## 4. Seed the database

```bash
cd server
npm run seed
```

The provided assignment text references a Version 3 seed, but the uploaded reference did not contain the complete official Version 3 option/rate table. Therefore `src/config/seed.js` contains clearly marked illustrative seed values. Replace those values with the official Version 3 seed supplied by the evaluator/brief before final submission.

## 5. Run

From the root:

```bash
npm run dev
```

Frontend:

```text
http://localhost:5173
```

Owner panel:

```text
http://localhost:5173/admin/login
```

Backend health:

```text
http://localhost:5000/api/health
```

## 6. Test owner credentials

Use the values in `server/.env`:

```text
Username: admin
Password: roofing2026!
```

## 7. API endpoints

### Public

- `GET /api/config`
- `POST /api/estimate`
- `POST /api/auth/login`
- `GET /api/health`

### Owner

- `PUT /api/admin/config`
- `GET /api/admin/leads`

Owner endpoints require HTTP Basic Authentication.

## 8. Pricing formula

```text
Base Material Cost = A × Rm × (1 + W)
Tear-Off Cost      = A × Rt
Adjusted Subtotal  = (Base Material Cost + Tear-Off Cost) × Mp × Ms
Mid Estimate       = Adjusted Subtotal + Permit Fee
Low Estimate       = Mid Estimate × (1 - Spread)
High Estimate      = Mid Estimate × (1 + Spread)
```

Default modifiers:

```text
Waste factor: 10%
Permit fee: $350
Range spread: 12%
```

The calculation is performed only on the server.

## 9. Important assignment constraint

Do not put question text, option rates, multipliers, or pricing constants in React components. The public frontend obtains these values through `/api/config`.

## 10. Production deployment

Frontend can be deployed to Vercel/Netlify.

Backend can be deployed to Render/Railway.

MongoDB can be hosted with MongoDB Atlas.

Set:

```env
CLIENT_ORIGIN=https://your-frontend-domain.example
MONGODB_URI=your-production-mongodb-uri
ADMIN_USERNAME=your-admin-user
ADMIN_PASSWORD=your-strong-password
```

Never commit `.env`.
