import React from 'react';
import {
  Link,
  Route,
  Routes
} from 'react-router-dom';
import Estimator from './pages/Estimator.jsx';
import AdminLogin from './pages/AdminLogin.jsx';
import OwnerPanel from './pages/OwnerPanel.jsx';

export default function App() {
  return (
    <>
      <header className="topbar">
        <div className="container nav">
          <Link className="brand" to="/">
            Northline Roofing
          </Link>

          <Link className="nav-link" to="/admin/login">
            Owner Panel
          </Link>
        </div>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<Estimator />} />
          <Route path="/admin/login" element={<AdminLogin />} />
          <Route path="/admin" element={<OwnerPanel />} />
        </Routes>
      </main>
    </>
  );
}
