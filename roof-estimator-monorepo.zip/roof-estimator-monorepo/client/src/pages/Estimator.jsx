import React, { useEffect, useMemo, useState } from 'react';
import QuestionField from '../components/dynamic/QuestionField.jsx';
import {
  getConfig,
  submitEstimate
} from '../services/api.js';

export default function Estimator() {
  const [config, setConfig] = useState(null);
  const [answers, setAnswers] = useState({});
  const [step, setStep] = useState(0);
  const [contact, setContact] = useState({
    name: '',
    phone: '',
    email: ''
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    getConfig()
      .then(setConfig)
      .catch((err) =>
        setError(err.message)
      )
      .finally(() => setLoading(false));
  }, []);

  const questions = useMemo(
    () =>
      config?.questions
        ?.filter((q) => q.active)
        ?.sort((a, b) => a.order - b.order) || [],
    [config]
  );

  if (loading) {
    return <div className="card">Loading estimator...</div>;
  }

  if (error) {
    return <div className="card error">{error}</div>;
  }

  if (!config) return null;

  const totalSteps = questions.length + 1;
  const isContactStep = step === questions.length;

  function setAnswer(key, value) {
    setAnswers((previous) => ({
      ...previous,
      [key]: value
    }));
  }

  function validateCurrentStep() {
    if (isContactStep) {
      if (
        !contact.name.trim() ||
        !contact.phone.trim() ||
        !contact.email.trim()
      ) {
        setError('Please complete all contact fields.');
        return false;
      }

      if (!/^\S+@\S+\.\S+$/.test(contact.email)) {
        setError('Please enter a valid email address.');
        return false;
      }

      return true;
    }

    const question = questions[step];
    const value = answers[question.key];

    if (
      question.required &&
      (value === undefined ||
        value === null ||
        value === '')
    ) {
      setError('Please answer this question.');
      return false;
    }

    if (
      question.type === 'number' &&
      value !== '' &&
      value !== undefined
    ) {
      if (
        question.min !== undefined &&
        Number(value) < question.min
      ) {
        setError(
          `Value must be at least ${question.min}.`
        );
        return false;
      }

      if (
        question.max !== undefined &&
        Number(value) > question.max
      ) {
        setError(
          `Value must be at most ${question.max}.`
        );
        return false;
      }
    }

    return true;
  }

  function next() {
    setError('');

    if (!validateCurrentStep()) return;

    setStep((current) =>
      Math.min(current + 1, totalSteps - 1)
    );
  }

  function back() {
    setError('');
    setStep((current) => Math.max(current - 1, 0));
  }

  async function calculate() {
    setError('');

    if (!validateCurrentStep()) return;

    setSubmitting(true);

    try {
      const response = await submitEstimate({
        ...contact,
        answers
      });

      setResult(response);
    } catch (err) {
      const detail =
        Array.isArray(err.details)
          ? ` ${err.details.join(' ')}`
          : '';

      setError(`${err.message}${detail}`);
    } finally {
      setSubmitting(false);
    }
  }

  function reset() {
    setAnswers({});
    setContact({
      name: '',
      phone: '',
      email: ''
    });
    setStep(0);
    setResult(null);
    setError('');
  }

  if (result) {
    return (
      <section className="hero">
        <div className="card result">
          <p className="eyebrow">Estimate ready</p>
          <h1>Your roofing estimate range</h1>

          <div className="estimate">
            <strong>
              {new Intl.NumberFormat(
                'en-US',
                {
                  style: 'currency',
                  currency:
                    config.business.currency || 'USD',
                  maximumFractionDigits: 0
                }
              ).format(result.estimate_low)}
              {' - '}
              {new Intl.NumberFormat(
                'en-US',
                {
                  style: 'currency',
                  currency:
                    config.business.currency || 'USD',
                  maximumFractionDigits: 0
                }
              ).format(result.estimate_high)}
            </strong>
          </div>

          <p>
            This is a preliminary estimate based on the
            information you provided.
          </p>

          <button onClick={reset}>
            Start another estimate
          </button>
        </div>
      </section>
    );
  }

  const currentQuestion = questions[step];

  return (
    <section className="hero">
      <div className="card">
        <p className="eyebrow">
          {config.business.name}
        </p>

        <h1>Get a roofing estimate</h1>

        <p className="muted">
          Answer a few questions to receive a
          preliminary cost range.
        </p>

        <div className="progress">
          Step {step + 1} of {totalSteps}
        </div>

        {isContactStep ? (
          <div>
            <h2>Contact information</h2>

            <div className="field">
              <label>Name</label>
              <input
                value={contact.name}
                onChange={(e) =>
                  setContact({
                    ...contact,
                    name: e.target.value
                  })
                }
              />
            </div>

            <div className="field">
              <label>Phone</label>
              <input
                value={contact.phone}
                onChange={(e) =>
                  setContact({
                    ...contact,
                    phone: e.target.value
                  })
                }
              />
            </div>

            <div className="field">
              <label>Email</label>
              <input
                type="email"
                value={contact.email}
                onChange={(e) =>
                  setContact({
                    ...contact,
                    email: e.target.value
                  })
                }
              />
            </div>
          </div>
        ) : (
          <QuestionField
            question={currentQuestion}
            value={answers[currentQuestion.key]}
            onChange={setAnswer}
          />
        )}

        {error && (
          <div className="error">{error}</div>
        )}

        <div className="actions">
          {step > 0 && (
            <button
              className="secondary"
              onClick={back}
            >
              Back
            </button>
          )}

          {!isContactStep ? (
            <button onClick={next}>Continue</button>
          ) : (
            <button
              onClick={calculate}
              disabled={submitting}
            >
              {submitting
                ? 'Calculating...'
                : 'Calculate Estimate'}
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
