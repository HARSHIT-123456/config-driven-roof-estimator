import React, { useEffect, useState } from 'react';
import {
  getConfig
} from '../services/api.js';
import {
  getLeads,
  updateConfig
} from '../services/api.js';

export default function OwnerPanel() {
  const [config, setConfig] = useState(null);
  const [leads, setLeads] = useState([]);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [saving, setSaving] = useState(false);

  const username =
    sessionStorage.getItem('owner_username');

  const password =
    sessionStorage.getItem('owner_password');

  useEffect(() => {
    if (!username || !password) {
      window.location.href = '/admin/login';
      return;
    }

    Promise.all([
      getConfig(),
      getLeads(username, password)
    ])
      .then(([configData, leadsData]) => {
        setConfig(configData);
        setLeads(leadsData);
      })
      .catch((err) => {
        if (err.status === 401) {
          logout();
          return;
        }

        setError(err.message);
      });
  }, []);

  function logout() {
    sessionStorage.removeItem('owner_username');
    sessionStorage.removeItem('owner_password');
    window.location.href = '/admin/login';
  }

  function updateQuestion(
    questionIndex,
    field,
    value
  ) {
    setConfig((previous) => {
      const questions = [...previous.questions];

      questions[questionIndex] = {
        ...questions[questionIndex],
        [field]: value
      };

      return {
        ...previous,
        questions
      };
    });
  }

  function updateOption(
    questionIndex,
    optionIndex,
    field,
    value
  ) {
    setConfig((previous) => {
      const questions = [...previous.questions];

      const options = [
        ...questions[questionIndex].options
      ];

      options[optionIndex] = {
        ...options[optionIndex],
        [field]:
          field === 'rate_per_sqft' ||
          field === 'multiplier' ||
          field === 'tear_off_per_sqft'
            ? Number(value)
            : value
      };

      questions[questionIndex] = {
        ...questions[questionIndex],
        options
      };

      return {
        ...previous,
        questions
      };
    });
  }

  async function save() {
    setSaving(true);
    setError('');
    setMessage('');

    try {
      const response = await updateConfig(
        username,
        password,
        {
          questions: config.questions,
          modifiers: config.modifiers,
          business: config.business
        }
      );

      setMessage(
        `Saved as configuration version ${response.config_version}.`
      );
    } catch (err) {
      if (err.status === 401) {
        logout();
        return;
      }

      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (!config) {
    return (
      <div className="card">
        {error || 'Loading owner panel...'}
      </div>
    );
  }

  return (
    <section className="admin">
      <div className="admin-header">
        <div>
          <p className="eyebrow">Owner Panel</p>
          <h1>Configuration & Leads</h1>
          <p className="muted">
            Current version: {config.config_version}
          </p>
        </div>

        <button
          className="secondary"
          onClick={logout}
        >
          Logout
        </button>
      </div>

      {message && (
        <div className="success">{message}</div>
      )}

      {error && (
        <div className="error">{error}</div>
      )}

      <div className="card">
        <h2>Pricing modifiers</h2>

        <div className="grid-3">
          <div className="field">
            <label>Waste factor</label>
            <input
              type="number"
              step="0.01"
              value={config.modifiers.waste_factor}
              onChange={(e) =>
                setConfig({
                  ...config,
                  modifiers: {
                    ...config.modifiers,
                    waste_factor: Number(
                      e.target.value
                    )
                  }
                })
              }
            />
          </div>

          <div className="field">
            <label>Permit fee</label>
            <input
              type="number"
              value={
                config.modifiers.permit_flat_fee
              }
              onChange={(e) =>
                setConfig({
                  ...config,
                  modifiers: {
                    ...config.modifiers,
                    permit_flat_fee: Number(
                      e.target.value
                    )
                  }
                })
              }
            />
          </div>

          <div className="field">
            <label>Range spread %</label>
            <input
              type="number"
              value={
                config.modifiers.range_spread_pct
              }
              onChange={(e) =>
                setConfig({
                  ...config,
                  modifiers: {
                    ...config.modifiers,
                    range_spread_pct: Number(
                      e.target.value
                    )
                  }
                })
              }
            />
          </div>
        </div>
      </div>

      {config.questions.map(
        (question, questionIndex) => (
          <div
            className="card"
            key={question.key}
          >
            <div className="question-header">
              <h2>{question.key}</h2>

              <label className="toggle">
                <input
                  type="checkbox"
                  checked={question.active}
                  onChange={(e) =>
                    updateQuestion(
                      questionIndex,
                      'active',
                      e.target.checked
                    )
                  }
                />
                Active
              </label>
            </div>

            <div className="field">
              <label>Label</label>
              <input
                value={question.label}
                onChange={(e) =>
                  updateQuestion(
                    questionIndex,
                    'label',
                    e.target.value
                  )
                }
              />
            </div>

            {question.options?.length > 0 && (
              <div>
                <h3>Options</h3>

                {question.options.map(
                  (option, optionIndex) => (
                    <div
                      className="option-editor"
                      key={option.value}
                    >
                      <input
                        value={option.label}
                        onChange={(e) =>
                          updateOption(
                            questionIndex,
                            optionIndex,
                            'label',
                            e.target.value
                          )
                        }
                      />

                      <input
                        value={option.value}
                        onChange={(e) =>
                          updateOption(
                            questionIndex,
                            optionIndex,
                            'value',
                            e.target.value
                          )
                        }
                      />

                      {option.rate_per_sqft !==
                        undefined && (
                        <input
                          type="number"
                          step="0.01"
                          value={
                            option.rate_per_sqft
                          }
                          onChange={(e) =>
                            updateOption(
                              questionIndex,
                              optionIndex,
                              'rate_per_sqft',
                              e.target.value
                            )
                          }
                          placeholder="Rate/sqft"
                        />
                      )}

                      {option.multiplier !==
                        undefined && (
                        <input
                          type="number"
                          step="0.01"
                          value={
                            option.multiplier
                          }
                          onChange={(e) =>
                            updateOption(
                              questionIndex,
                              optionIndex,
                              'multiplier',
                              e.target.value
                            )
                          }
                          placeholder="Multiplier"
                        />
                      )}

                      {option.tear_off_per_sqft !==
                        undefined && (
                        <input
                          type="number"
                          step="0.01"
                          value={
                            option.tear_off_per_sqft
                          }
                          onChange={(e) =>
                            updateOption(
                              questionIndex,
                              optionIndex,
                              'tear_off_per_sqft',
                              e.target.value
                            )
                          }
                          placeholder="Tear-off/sqft"
                        />
                      )}
                    </div>
                  )
                )}
              </div>
            )}
          </div>
        )
      )}

      <button
        onClick={save}
        disabled={saving}
      >
        {saving ? 'Saving...' : 'Save Changes'}
      </button>

      <div className="card">
        <h2>Captured leads</h2>

        {leads.length === 0 ? (
          <p className="muted">No leads yet.</p>
        ) : (
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Date</th>
                  <th>Estimate</th>
                  <th>Version</th>
                </tr>
              </thead>

              <tbody>
                {leads.map((lead) => (
                  <tr key={lead._id}>
                    <td>{lead.name}</td>
                    <td>{lead.phone}</td>
                    <td>{lead.email}</td>
                    <td>
                      {new Date(
                        lead.createdAt
                      ).toLocaleString()}
                    </td>
                    <td>
                      ${lead.estimate_low} - $
                      {lead.estimate_high}
                    </td>
                    <td>{lead.config_version}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
}
