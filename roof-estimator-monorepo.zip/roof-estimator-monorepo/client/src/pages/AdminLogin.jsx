import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { loginOwner } from '../services/api.js';

export default function AdminLogin() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    username: '',
    password: ''
  });

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setError('');
    setLoading(true);

    try {
      await loginOwner(form);

      sessionStorage.setItem(
        'owner_username',
        form.username
      );

      sessionStorage.setItem(
        'owner_password',
        form.password
      );

      navigate('/admin');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="hero">
      <form className="card narrow" onSubmit={submit}>
        <p className="eyebrow">Owner Panel</p>
        <h1>Sign in</h1>

        <div className="field">
          <label>Username</label>
          <input
            value={form.username}
            onChange={(e) =>
              setForm({
                ...form,
                username: e.target.value
              })
            }
          />
        </div>

        <div className="field">
          <label>Password</label>
          <input
            type="password"
            value={form.password}
            onChange={(e) =>
              setForm({
                ...form,
                password: e.target.value
              })
            }
          />
        </div>

        {error && (
          <div className="error">{error}</div>
        )}

        <button disabled={loading}>
          {loading ? 'Signing in...' : 'Sign in'}
        </button>
      </form>
    </section>
  );
}
