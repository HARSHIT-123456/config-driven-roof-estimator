const API_URL =
  import.meta.env.VITE_API_URL ||
  'http://localhost:5000/api';

async function request(path, options = {}) {
  const response = await fetch(`${API_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const error = new Error(
      data.error || 'Request failed'
    );
    error.status = response.status;
    error.details = data.details;
    throw error;
  }

  return data;
}

export function getConfig() {
  return request('/config');
}

export function submitEstimate(payload) {
  return request('/estimate', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

export function loginOwner(payload) {
  return request('/auth/login', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

function basicAuth(username, password) {
  return `Basic ${btoa(`${username}:${password}`)}`;
}

export function getLeads(username, password) {
  return request('/admin/leads', {
    headers: {
      Authorization: basicAuth(username, password)
    }
  });
}

export function updateConfig(
  username,
  password,
  config
) {
  return request('/admin/config', {
    method: 'PUT',
    headers: {
      Authorization: basicAuth(username, password)
    },
    body: JSON.stringify(config)
  });
}
