import React from 'react';

export default function QuestionField({
  question,
  value,
  onChange
}) {
  if (!question.active) return null;

  if (question.type === 'number') {
    return (
      <div className="field">
        <label>
          {question.label}
          {question.unit
            ? ` (${question.unit})`
            : ''}
        </label>

        <input
          type="number"
          min={question.min}
          max={question.max}
          value={value ?? ''}
          onChange={(event) => {
            const raw = event.target.value;
            onChange(
              question.key,
              raw === '' ? '' : Number(raw)
            );
          }}
          required={question.required}
          placeholder={
            question.min !== undefined &&
            question.max !== undefined
              ? `${question.min} - ${question.max}`
              : ''
          }
        />
      </div>
    );
  }

  if (question.type === 'select') {
    return (
      <div className="field">
        <label>{question.label}</label>

        <div className="options">
          {question.options.map((option) => (
            <label
              className={
                value === option.value
                  ? 'option selected'
                  : 'option'
              }
              key={option.value}
            >
              <span>{option.label}</span>

              <input
                type="radio"
                name={question.key}
                value={option.value}
                checked={value === option.value}
                onChange={() =>
                  onChange(
                    question.key,
                    option.value
                  )
                }
              />
            </label>
          ))}
        </div>
      </div>
    );
  }

  return null;
}
