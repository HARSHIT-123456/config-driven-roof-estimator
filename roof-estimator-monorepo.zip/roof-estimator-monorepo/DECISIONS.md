# Architectural Decisions

## Stack

I selected React + Vite for the public estimator and owner panel, Express.js for the API, and MongoDB with Mongoose for persistence.

Reasons:

- Fast development and simple component architecture.
- REST endpoints clearly separate frontend and backend responsibilities.
- MongoDB is suitable for configuration documents containing nested questions and options.
- Mongoose provides validation and schema control.
- The stack is easy to run locally and deploy independently.

## Configuration-driven design

Questions and options are stored in MongoDB. The React application does not contain business pricing values or hardcoded estimator questions.

The estimator calls:

```text
GET /api/config
```

and renders the returned active questions.

## Pricing calculation

The backend calculates:

```text
Base Material Cost = roof area × material rate × (1 + waste factor)

Tear-Off Cost = roof area × tear-off rate

Adjusted Subtotal =
  (Base Material Cost + Tear-Off Cost)
  × pitch multiplier
  × stories multiplier

Mid Estimate = Adjusted Subtotal + permit fee

Low = Mid Estimate × (1 - spread percentage)

High = Mid Estimate × (1 + spread percentage)
```

The calculation is deliberately server-side so a customer cannot change a browser-side formula and submit a false price.

## Authentication

The owner panel uses HTTP Basic Authentication for the assignment's simple authentication requirement.

For a production application I would replace this with a proper session-based authentication system, hashed passwords, CSRF protection where applicable, rate limiting, audit logs, and role-based permissions.

## Versioning

Every configuration update increments `config_version`. Leads store the version used to calculate their estimate, making it possible to identify which configuration produced an estimate.

## Out of scope

The implementation does not include:

- Multiple organizations/tenants
- Complex role/permission management
- Password reset
- Email/SMS notifications
- Payment processing
- Customer accounts
- Advanced audit logging

## Seed-data note

The assignment reference says that an official Version 3 seed is supplied in the brief. The uploaded reference available for this implementation did not include the complete Version 3 option/rate table. The seed file therefore contains illustrative values and is intentionally documented so the official seed can be substituted before final submission.

## Questions for Dale before production

1. What exact Version 3 prices should be used?
2. Should permit fees vary by city or project type?
3. Are the 12% low/high ranges fixed for every project?
4. Should taxes be included?
5. Which customer contact fields are mandatory?
6. Should leads be exportable to CSV?
7. Who can edit pricing?
8. How long should lead data be retained?
9. Should owners receive notifications for new leads?
10. What privacy/consent wording is required on the estimator?
