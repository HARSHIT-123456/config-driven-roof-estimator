# AI Usage Log

## Tools used

- ChatGPT
- VS Code
- Node.js documentation / package documentation as needed

## Example AI mistake and correction

An AI-generated implementation could accidentally calculate pricing in the browser or hardcode option rates in a React component. That would violate the assignment's configuration-driven requirement.

Correction:

- React only renders configuration received from `GET /api/config`.
- `POST /api/estimate` sends answers to the server.
- The server loads the active MongoDB configuration and calculates the estimate.
- The server stores the resulting lead and configuration version.

## Another validation concern

Configuration values may arrive as numeric strings in legacy seed data. The calculator therefore converts rates and multipliers using `Number(...)` before arithmetic.

## Code authored/verified directly

The final project structure, API routes, database models, calculator, dynamic form renderer, owner configuration editor, authentication flow, seed script, and documentation were assembled and checked against the assignment requirements.

## Human verification required

Before submission, manually verify:

1. Official Version 3 seed values have replaced illustrative seed values.
2. Owner rate changes affect new estimates without redeploying.
3. Unauthenticated owner requests are rejected.
4. Leads are stored in MongoDB.
5. Frontend contains no pricing constants/questions.
6. Deployment URLs are live.
