import { Config } from '../models/Config.js';
import { Lead } from '../models/Lead.js';
import { calculateEstimate } from '../services/calculator.js';
import { validateAnswers } from '../services/validation.js';

export async function createEstimate(req, res) {
  const { name, phone, email, answers } = req.body || {};

  if (!name || !phone || !email || !answers) {
    return res.status(400).json({
      error: 'name, phone, email and answers are required'
    });
  }

  const config = await Config.findOne({ active: true })
    .sort({ config_version: -1 })
    .lean();

  if (!config) {
    return res.status(500).json({
      error: 'No active configuration found'
    });
  }

  const validationErrors = validateAnswers(config, answers);

  if (validationErrors.length) {
    return res.status(400).json({
      error: 'Validation failed',
      details: validationErrors
    });
  }

  const estimate = calculateEstimate(config, answers);

  const lead = await Lead.create({
    name,
    phone,
    email,
    answers,
    estimate_low: estimate.estimate_low,
    estimate_high: estimate.estimate_high,
    config_version: config.config_version
  });

  res.status(201).json({
    lead_id: lead._id,
    config_version: config.config_version,
    estimate_low: estimate.estimate_low,
    estimate_high: estimate.estimate_high,
    estimate_mid: estimate.estimate_mid
  });
}

export async function getLeads(req, res) {
  const leads = await Lead.find()
    .sort({ createdAt: -1 })
    .lean();

  res.json(leads);
}
