import { Config } from '../models/Config.js';

export async function getPublicConfig(req, res) {
  const config = await Config.findOne({ active: true })
    .sort({ config_version: -1 })
    .lean();

  if (!config) {
    return res.status(404).json({
      error: 'No active configuration found'
    });
  }

  const publicConfig = {
    config_version: config.config_version,
    business: config.business,
    questions: [...config.questions]
      .filter((question) => question.active)
      .sort((a, b) => a.order - b.order)
      .map((question) => ({
        key: question.key,
        label: question.label,
        type: question.type,
        unit: question.unit,
        required: question.required,
        min: question.min,
        max: question.max,
        active: question.active,
        order: question.order,
        options: question.options
      }))
  };

  res.json(publicConfig);
}

export async function updateConfig(req, res) {
  const current = await Config.findOne({ active: true })
    .sort({ config_version: -1 });

  if (!current) {
    return res.status(404).json({
      error: 'No active configuration found'
    });
  }

  const body = req.body || {};

  if (body.business) {
    current.business = {
      ...current.business.toObject(),
      ...body.business
    };
  }

  if (Array.isArray(body.questions)) {
    current.questions = body.questions;
  }

  if (body.modifiers) {
    current.modifiers = {
      ...current.modifiers.toObject(),
      ...body.modifiers
    };
  }

  current.config_version += 1;
  current.active = true;

  await Config.updateMany(
    { _id: { $ne: current._id }, active: true },
    { $set: { active: false } }
  );

  await current.save();

  res.json({
    message: 'Configuration updated',
    config_version: current.config_version
  });
}
