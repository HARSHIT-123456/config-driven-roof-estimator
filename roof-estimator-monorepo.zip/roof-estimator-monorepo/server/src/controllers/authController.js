export function login(req, res) {
  const { username, password } = req.body || {};

  const adminUser = process.env.ADMIN_USERNAME || 'admin';
  const adminPass =
    process.env.ADMIN_PASSWORD || 'roofing2026!';

  if (username !== adminUser || password !== adminPass) {
    return res.status(401).json({
      success: false,
      error: 'Invalid username or password'
    });
  }

  return res.json({
    success: true,
    message: 'Login successful'
  });
}
