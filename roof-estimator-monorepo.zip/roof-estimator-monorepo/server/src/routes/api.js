import { Router } from 'express';
import { login } from '../controllers/authController.js';
import {
  getPublicConfig,
  updateConfig
} from '../controllers/configController.js';
import {
  createEstimate,
  getLeads
} from '../controllers/leadController.js';
import { requireOwnerAuth } from '../middleware/auth.js';

const router = Router();

router.get('/health', (req, res) => {
  res.json({ ok: true });
});

router.get('/config', getPublicConfig);
router.post('/estimate', createEstimate);
router.post('/auth/login', login);

router.put(
  '/admin/config',
  requireOwnerAuth,
  updateConfig
);

router.get(
  '/admin/leads',
  requireOwnerAuth,
  getLeads
);

export default router;
