import 'dotenv/config';
import mongoose from 'mongoose';
import { connectDB } from './db.js';
import { Config } from '../models/Config.js';

const seedConfig = {
  config_version: 3,
  active: true,
  business: {
    name: 'Northline Roofing & Exteriors',
    region: 'United States',
    currency: 'USD'
  },
  questions: [
    {
      key: 'roof_area',
      label: 'What is the approximate roof area?',
      type: 'number',
      unit: 'sq ft',
      required: true,
      min: 500,
      max: 10000,
      active: true,
      order: 1,
      options: []
    },
    {
      key: 'material',
      label: 'Which roofing material do you prefer?',
      type: 'select',
      required: true,
      active: true,
      order: 2,
      options: [
        {
          value: 'asphalt_3tab',
          label: '3-Tab Asphalt Shingle',
          rate_per_sqft: 4.25
        },
        {
          value: 'architectural',
          label: 'Architectural Shingle',
          rate_per_sqft: 5.50
        },
        {
          value: 'premium',
          label: 'Premium Roofing',
          rate_per_sqft: 7.00
        }
      ]
    },
    {
      key: 'pitch',
      label: 'What is the roof pitch?',
      type: 'select',
      required: true,
      active: true,
      order: 3,
      options: [
        {
          value: 'low',
          label: 'Low / Easy',
          multiplier: 1.00
        },
        {
          value: 'medium',
          label: 'Medium',
          multiplier: 1.12
        },
        {
          value: 'steep',
          label: 'Steep',
          multiplier: 1.25
        }
      ]
    },
    {
      key: 'layers',
      label: 'How many existing roof layers need removal?',
      type: 'select',
      required: true,
      active: true,
      order: 4,
      options: [
        {
          value: 'one',
          label: 'One layer',
          tear_off_per_sqft: 0.75
        },
        {
          value: 'two',
          label: 'Two layers',
          tear_off_per_sqft: 1.25
        }
      ]
    },
    {
      key: 'stories',
      label: 'How many stories is the property?',
      type: 'select',
      required: true,
      active: true,
      order: 5,
      options: [
        {
          value: 'one',
          label: '1 story',
          multiplier: 1.00
        },
        {
          value: 'two',
          label: '2 stories',
          multiplier: 1.08
        },
        {
          value: 'three',
          label: '3+ stories',
          multiplier: 1.18
        }
      ]
    }
  ],
  modifiers: {
    waste_factor: 0.10,
    permit_flat_fee: 350,
    range_spread_pct: 12
  }
};

async function seed() {
  try {
    await connectDB();

    await Config.updateMany(
      {},
      { $set: { active: false } }
    );

    await Config.findOneAndUpdate(
      { config_version: seedConfig.config_version },
      seedConfig,
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true
      }
    );

    console.log('Seed completed.');
  } catch (error) {
    console.error(error);
    process.exitCode = 1;
  } finally {
    await mongoose.disconnect();
  }
}

seed();
