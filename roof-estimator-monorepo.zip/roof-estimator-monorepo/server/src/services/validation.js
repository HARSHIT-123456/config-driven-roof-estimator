export function validateAnswers(config, answers) {
  const errors = [];

  for (const question of config.questions.filter((q) => q.active)) {
    const value = answers?.[question.key];

    if (
      question.required &&
      (value === undefined || value === null || value === '')
    ) {
      errors.push(`${question.label} is required`);
      continue;
    }

    if (question.type === 'number' && value !== undefined) {
      const numeric = Number(value);

      if (!Number.isFinite(numeric)) {
        errors.push(`${question.label} must be a valid number`);
        continue;
      }

      if (question.min !== undefined && numeric < question.min) {
        errors.push(`${question.label} must be at least ${question.min}`);
      }

      if (question.max !== undefined && numeric > question.max) {
        errors.push(`${question.label} must be at most ${question.max}`);
      }
    }

    if (question.type === 'select' && value !== undefined) {
      const valid = question.options.some(
        (option) => option.value === value
      );

      if (!valid) {
        errors.push(`${question.label} has an invalid selection`);
      }
    }
  }

  return errors;
}
