export function requireOwnerAuth(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith('Basic ')) {
    res.setHeader(
      'WWW-Authenticate',
      'Basic realm="Owner Panel"'
    );
    return res.status(401).json({
      error: 'Authentication required'
    });
  }

  let decoded = '';

  try {
    decoded = Buffer.from(
      authHeader.slice(6),
      'base64'
    ).toString('utf8');
  } catch {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const separator = decoded.indexOf(':');

  if (separator < 0) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const user = decoded.slice(0, separator);
  const pass = decoded.slice(separator + 1);

  const adminUser = process.env.ADMIN_USERNAME || 'admin';
  const adminPass =
    process.env.ADMIN_PASSWORD || 'roofing2026!';

  if (user !== adminUser || pass !== adminPass) {
    res.setHeader(
      'WWW-Authenticate',
      'Basic realm="Owner Panel"'
    );
    return res.status(401).json({
      error: 'Invalid credentials'
    });
  }

  req.owner = { username: user };
  next();
}
